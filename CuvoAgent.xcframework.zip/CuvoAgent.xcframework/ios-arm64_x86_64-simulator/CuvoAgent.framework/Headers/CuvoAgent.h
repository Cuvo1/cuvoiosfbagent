//
//  CuvoAgent.h
//  CuvoAgent
//
//  Created by siva chandran on 04/02/23.
//

#import <Foundation/Foundation.h>

//! Project version number for CuvoAgent.
FOUNDATION_EXPORT double CuvoAgentVersionNumber;

//! Project version string for CuvoAgent.
FOUNDATION_EXPORT const unsigned char CuvoAgentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CuvoAgent/PublicHeader.h>

